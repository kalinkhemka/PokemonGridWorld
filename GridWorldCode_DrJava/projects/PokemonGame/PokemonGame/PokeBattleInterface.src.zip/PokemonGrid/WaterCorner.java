/*    */ package PokemonGrid;
/*    */ 
/*    */ import info.gridworld.actor.Actor;
/*    */ 
/*    */ public class WaterCorner extends Actor
/*    */ {
/*    */   public WaterCorner(int direction)
/*    */   {
/* 11 */     setColor(null);
/* 12 */     setDirection(direction);
/*    */   }
/*    */ 
/*    */   public void act()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     PokemonGrid.WaterCorner
 * JD-Core Version:    0.6.0
 */