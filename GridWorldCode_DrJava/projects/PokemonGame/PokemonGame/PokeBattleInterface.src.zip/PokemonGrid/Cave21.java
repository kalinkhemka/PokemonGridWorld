/*    */ package PokemonGrid;
/*    */ 
/*    */ import info.gridworld.actor.Actor;
/*    */ 
/*    */ public class Cave21 extends Actor
/*    */ {
/*    */   public Cave21()
/*    */   {
/* 11 */     setColor(null);
/*    */   }
/*    */ 
/*    */   public void act()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     PokemonGrid.Cave21
 * JD-Core Version:    0.6.0
 */