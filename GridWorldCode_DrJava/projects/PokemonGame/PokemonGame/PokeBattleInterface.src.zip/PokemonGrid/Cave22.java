/*    */ package PokemonGrid;
/*    */ 
/*    */ import info.gridworld.actor.Actor;
/*    */ 
/*    */ public class Cave22 extends Actor
/*    */ {
/*    */   public Cave22()
/*    */   {
/* 11 */     setColor(null);
/*    */   }
/*    */ 
/*    */   public void act()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     PokemonGrid.Cave22
 * JD-Core Version:    0.6.0
 */