/*    */ package PokemonGrid;
/*    */ 
/*    */ import info.gridworld.actor.Actor;
/*    */ 
/*    */ public class Cave14 extends Actor
/*    */ {
/*    */   public Cave14()
/*    */   {
/* 11 */     setColor(null);
/*    */   }
/*    */ 
/*    */   public void act()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     PokemonGrid.Cave14
 * JD-Core Version:    0.6.0
 */