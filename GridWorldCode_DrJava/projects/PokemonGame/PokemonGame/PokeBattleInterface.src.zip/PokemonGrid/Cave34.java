/*    */ package PokemonGrid;
/*    */ 
/*    */ import info.gridworld.actor.Actor;
/*    */ 
/*    */ public class Cave34 extends Actor
/*    */ {
/*    */   public Cave34()
/*    */   {
/* 11 */     setColor(null);
/*    */   }
/*    */ 
/*    */   public void act()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     PokemonGrid.Cave34
 * JD-Core Version:    0.6.0
 */