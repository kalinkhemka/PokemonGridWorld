/*    */ package info.gridworld.actor;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class Rock extends Actor
/*    */ {
/* 31 */   private static final Color DEFAULT_COLOR = Color.BLACK;
/*    */ 
/*    */   public Rock()
/*    */   {
/* 38 */     setColor(DEFAULT_COLOR);
/*    */   }
/*    */ 
/*    */   public Rock(Color rockColor)
/*    */   {
/* 47 */     setColor(rockColor);
/*    */   }
/*    */ 
/*    */   public void act()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     info.gridworld.actor.Rock
 * JD-Core Version:    0.6.0
 */