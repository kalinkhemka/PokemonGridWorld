/*   */ package Pokemon;
/*   */ 
/*   */ public class ShadowClaw extends Attack
/*   */ {
/*   */   public ShadowClaw()
/*   */   {
/* 7 */     super("Shadow Claw", "ghost", 1.0D, 75, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.ShadowClaw
 * JD-Core Version:    0.6.0
 */