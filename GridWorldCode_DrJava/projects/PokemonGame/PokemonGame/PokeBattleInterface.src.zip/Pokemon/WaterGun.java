/*   */ package Pokemon;
/*   */ 
/*   */ public class WaterGun extends Attack
/*   */ {
/*   */   public WaterGun()
/*   */   {
/* 7 */     super("Water Gun", "water", 1.0D, 40, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.WaterGun
 * JD-Core Version:    0.6.0
 */