/*   */ package Pokemon;
/*   */ 
/*   */ public class LastResort extends Attack
/*   */ {
/*   */   public LastResort()
/*   */   {
/* 7 */     super("Last Resort", "normal", 1.0D, 140, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.LastResort
 * JD-Core Version:    0.6.0
 */