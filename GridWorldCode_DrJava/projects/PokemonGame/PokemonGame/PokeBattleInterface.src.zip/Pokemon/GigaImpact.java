/*   */ package Pokemon;
/*   */ 
/*   */ public class GigaImpact extends Attack
/*   */ {
/*   */   public GigaImpact()
/*   */   {
/* 7 */     super("Giga Impact", "normal", 0.9D, 150, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.GigaImpact
 * JD-Core Version:    0.6.0
 */