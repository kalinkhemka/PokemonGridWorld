/*   */ package Pokemon;
/*   */ 
/*   */ public class Overheat extends Attack
/*   */ {
/*   */   public Overheat()
/*   */   {
/* 7 */     super("Overheat", "fire", 0.9D, 140, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Overheat
 * JD-Core Version:    0.6.0
 */