/*   */ package Pokemon;
/*   */ 
/*   */ public class CloseCombat extends Attack
/*   */ {
/*   */   public CloseCombat()
/*   */   {
/* 7 */     super("Close Combat", "fighting", 1.0D, 120, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.CloseCombat
 * JD-Core Version:    0.6.0
 */