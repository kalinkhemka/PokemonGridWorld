/*   */ package Pokemon;
/*   */ 
/*   */ public class PowerGem extends Attack
/*   */ {
/*   */   public PowerGem()
/*   */   {
/* 7 */     super("Power Gem", "rock", 1.0D, 70, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.PowerGem
 * JD-Core Version:    0.6.0
 */