/*   */ package Pokemon;
/*   */ 
/*   */ public class RockThrow extends Attack
/*   */ {
/*   */   public RockThrow()
/*   */   {
/* 7 */     super("RockThrow", "rock", 0.9D, 50, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.RockThrow
 * JD-Core Version:    0.6.0
 */