/*   */ package Pokemon;
/*   */ 
/*   */ public class ShadowBall extends Attack
/*   */ {
/*   */   public ShadowBall()
/*   */   {
/* 7 */     super("Shadow Ball", "ghost", 1.0D, 80, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.ShadowBall
 * JD-Core Version:    0.6.0
 */