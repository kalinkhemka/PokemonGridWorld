/*   */ package Pokemon;
/*   */ 
/*   */ public class ChargeBeam extends Attack
/*   */ {
/*   */   public ChargeBeam()
/*   */   {
/* 7 */     super("ChargeBeam", "electric", 0.9D, 50, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.ChargeBeam
 * JD-Core Version:    0.6.0
 */