/*   */ package Pokemon;
/*   */ 
/*   */ public class Bounce extends Attack
/*   */ {
/*   */   public Bounce()
/*   */   {
/* 7 */     super("Bounce", "flying", 0.85D, 85, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Bounce
 * JD-Core Version:    0.6.0
 */