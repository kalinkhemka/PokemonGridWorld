/*   */ package Pokemon;
/*   */ 
/*   */ public class IceBeam extends Attack
/*   */ {
/*   */   public IceBeam()
/*   */   {
/* 7 */     super("Ice Beam", "ice", 1.0D, 95, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.IceBeam
 * JD-Core Version:    0.6.0
 */