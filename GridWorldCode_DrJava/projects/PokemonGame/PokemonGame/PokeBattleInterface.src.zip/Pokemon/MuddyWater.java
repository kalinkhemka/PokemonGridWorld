/*   */ package Pokemon;
/*   */ 
/*   */ public class MuddyWater extends Attack
/*   */ {
/*   */   public MuddyWater()
/*   */   {
/* 7 */     super("Muddy Water", "water", 0.85D, 95, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.MuddyWater
 * JD-Core Version:    0.6.0
 */