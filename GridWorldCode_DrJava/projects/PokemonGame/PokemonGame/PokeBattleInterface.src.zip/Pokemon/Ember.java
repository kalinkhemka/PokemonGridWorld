/*   */ package Pokemon;
/*   */ 
/*   */ public class Ember extends Attack
/*   */ {
/*   */   public Ember()
/*   */   {
/* 7 */     super("Ember", "fire", 1.0D, 40, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Ember
 * JD-Core Version:    0.6.0
 */