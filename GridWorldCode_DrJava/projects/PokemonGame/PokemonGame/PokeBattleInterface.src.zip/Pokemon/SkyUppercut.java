/*   */ package Pokemon;
/*   */ 
/*   */ public class SkyUppercut extends Attack
/*   */ {
/*   */   public SkyUppercut()
/*   */   {
/* 7 */     super("Sky Uppercut", "fighting", 0.9D, 85, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.SkyUppercut
 * JD-Core Version:    0.6.0
 */