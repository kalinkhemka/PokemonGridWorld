/*   */ package Pokemon;
/*   */ 
/*   */ public class SolarBeam extends Attack
/*   */ {
/*   */   public SolarBeam()
/*   */   {
/* 7 */     super("Solarbeam", "grass", 1.0D, 120, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.SolarBeam
 * JD-Core Version:    0.6.0
 */