/*   */ package Pokemon;
/*   */ 
/*   */ public class WingAttack extends Attack
/*   */ {
/*   */   public WingAttack()
/*   */   {
/* 7 */     super("WingAttack", "flying", 1.0D, 60, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.WingAttack
 * JD-Core Version:    0.6.0
 */