/*   */ package Pokemon;
/*   */ 
/*   */ public class SludgeBomb extends Attack
/*   */ {
/*   */   public SludgeBomb()
/*   */   {
/* 7 */     super("Sludge Bomb", "poison", 1.0D, 90, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.SludgeBomb
 * JD-Core Version:    0.6.0
 */