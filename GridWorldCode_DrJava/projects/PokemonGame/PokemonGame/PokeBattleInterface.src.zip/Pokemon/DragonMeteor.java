/*   */ package Pokemon;
/*   */ 
/*   */ public class DragonMeteor extends Attack
/*   */ {
/*   */   public DragonMeteor()
/*   */   {
/* 7 */     super("Dragon Meteor", "dragon", 0.9D, 140, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.DragonMeteor
 * JD-Core Version:    0.6.0
 */