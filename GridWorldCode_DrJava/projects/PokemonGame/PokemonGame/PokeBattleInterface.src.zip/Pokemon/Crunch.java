/*   */ package Pokemon;
/*   */ 
/*   */ public class Crunch extends Attack
/*   */ {
/*   */   public Crunch()
/*   */   {
/* 7 */     super("Crunch", "normal", 0.9D, 80, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Crunch
 * JD-Core Version:    0.6.0
 */