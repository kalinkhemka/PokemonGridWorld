/*   */ package Pokemon;
/*   */ 
/*   */ public class Bubble extends Attack
/*   */ {
/*   */   public Bubble()
/*   */   {
/* 7 */     super("Bubble", "water", 1.0D, 20, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Bubble
 * JD-Core Version:    0.6.0
 */