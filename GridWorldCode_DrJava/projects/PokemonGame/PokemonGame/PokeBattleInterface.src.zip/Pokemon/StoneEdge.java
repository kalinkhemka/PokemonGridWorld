/*   */ package Pokemon;
/*   */ 
/*   */ public class StoneEdge extends Attack
/*   */ {
/*   */   public StoneEdge()
/*   */   {
/* 7 */     super("Stone Edge", "rock", 0.8D, 100, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.StoneEdge
 * JD-Core Version:    0.6.0
 */