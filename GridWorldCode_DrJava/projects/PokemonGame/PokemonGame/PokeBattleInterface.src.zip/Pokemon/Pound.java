/*   */ package Pokemon;
/*   */ 
/*   */ public class Pound extends Attack
/*   */ {
/*   */   public Pound()
/*   */   {
/* 7 */     super("Pound", "normal", 1.0D, 40, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Pound
 * JD-Core Version:    0.6.0
 */