/*   */ package Pokemon;
/*   */ 
/*   */ public class MudSlap extends Attack
/*   */ {
/*   */   public MudSlap()
/*   */   {
/* 7 */     super("Mud-Slap", "ground", 1.0D, 20, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.MudSlap
 * JD-Core Version:    0.6.0
 */