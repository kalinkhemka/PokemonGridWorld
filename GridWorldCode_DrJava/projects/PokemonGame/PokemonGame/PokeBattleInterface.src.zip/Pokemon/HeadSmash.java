/*   */ package Pokemon;
/*   */ 
/*   */ public class HeadSmash extends Attack
/*   */ {
/*   */   public HeadSmash()
/*   */   {
/* 7 */     super("Head Smash", "rock", 0.8D, 150, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.HeadSmash
 * JD-Core Version:    0.6.0
 */