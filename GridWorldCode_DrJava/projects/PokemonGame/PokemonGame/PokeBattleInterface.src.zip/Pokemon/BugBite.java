/*   */ package Pokemon;
/*   */ 
/*   */ public class BugBite extends Attack
/*   */ {
/*   */   public BugBite()
/*   */   {
/* 7 */     super("Bug Bite", "bug", 1.0D, 60, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.BugBite
 * JD-Core Version:    0.6.0
 */