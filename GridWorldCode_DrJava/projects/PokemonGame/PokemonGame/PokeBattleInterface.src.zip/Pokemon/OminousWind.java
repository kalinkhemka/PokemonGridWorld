/*   */ package Pokemon;
/*   */ 
/*   */ public class OminousWind extends Attack
/*   */ {
/*   */   public OminousWind()
/*   */   {
/* 7 */     super("Ominous Wind", "ghost", 1.0D, 60, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.OminousWind
 * JD-Core Version:    0.6.0
 */