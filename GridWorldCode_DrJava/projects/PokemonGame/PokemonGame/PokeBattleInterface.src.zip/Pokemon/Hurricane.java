/*   */ package Pokemon;
/*   */ 
/*   */ public class Hurricane extends Attack
/*   */ {
/*   */   public Hurricane()
/*   */   {
/* 7 */     super("Hurricane", "flying", 0.7D, 120, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Hurricane
 * JD-Core Version:    0.6.0
 */