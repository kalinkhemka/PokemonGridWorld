/*   */ package Pokemon;
/*   */ 
/*   */ public class Scratch extends Attack
/*   */ {
/*   */   public Scratch()
/*   */   {
/* 7 */     super("Scratch", "normal", 1.0D, 40, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Scratch
 * JD-Core Version:    0.6.0
 */