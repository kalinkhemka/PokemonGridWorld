/*   */ package Pokemon;
/*   */ 
/*   */ public class BodySlam extends Attack
/*   */ {
/*   */   public BodySlam()
/*   */   {
/* 7 */     super("Body Slam", "normal", 1.0D, 85, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.BodySlam
 * JD-Core Version:    0.6.0
 */