/*   */ package Pokemon;
/*   */ 
/*   */ public class Peck extends Attack
/*   */ {
/*   */   public Peck()
/*   */   {
/* 7 */     super("Peck", "flying", 1.0D, 35, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Peck
 * JD-Core Version:    0.6.0
 */