/*   */ package Pokemon;
/*   */ 
/*   */ public class WaterPulse extends Attack
/*   */ {
/*   */   public WaterPulse()
/*   */   {
/* 7 */     super("Water Pulse", "water", 1.0D, 60, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.WaterPulse
 * JD-Core Version:    0.6.0
 */