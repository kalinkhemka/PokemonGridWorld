/*   */ package Pokemon;
/*   */ 
/*   */ public class Gust extends Attack
/*   */ {
/*   */   public Gust()
/*   */   {
/* 7 */     super("Gust", "flying", 1.0D, 40, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Gust
 * JD-Core Version:    0.6.0
 */