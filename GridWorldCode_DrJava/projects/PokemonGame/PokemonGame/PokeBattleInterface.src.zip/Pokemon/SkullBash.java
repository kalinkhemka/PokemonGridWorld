/*   */ package Pokemon;
/*   */ 
/*   */ public class SkullBash extends Attack
/*   */ {
/*   */   public SkullBash()
/*   */   {
/* 7 */     super("Skull Bash", "normal", 1.0D, 100, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.SkullBash
 * JD-Core Version:    0.6.0
 */