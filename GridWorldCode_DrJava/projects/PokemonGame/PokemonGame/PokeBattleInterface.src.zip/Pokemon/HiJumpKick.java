/*   */ package Pokemon;
/*   */ 
/*   */ public class HiJumpKick extends Attack
/*   */ {
/*   */   public HiJumpKick()
/*   */   {
/* 7 */     super("Hi Jump Kick", "fighting", 0.9D, 130, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.HiJumpKick
 * JD-Core Version:    0.6.0
 */