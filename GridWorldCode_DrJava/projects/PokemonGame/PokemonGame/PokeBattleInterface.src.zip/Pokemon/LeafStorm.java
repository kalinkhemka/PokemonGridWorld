/*   */ package Pokemon;
/*   */ 
/*   */ public class LeafStorm extends Attack
/*   */ {
/*   */   public LeafStorm()
/*   */   {
/* 7 */     super("LeafStorm", "grass", 0.9D, 140, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.LeafStorm
 * JD-Core Version:    0.6.0
 */