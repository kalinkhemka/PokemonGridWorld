/*   */ package Pokemon;
/*   */ 
/*   */ public class Bulldoze extends Attack
/*   */ {
/*   */   public Bulldoze()
/*   */   {
/* 7 */     super("Bulldoze", "ground", 1.0D, 60, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Bulldoze
 * JD-Core Version:    0.6.0
 */