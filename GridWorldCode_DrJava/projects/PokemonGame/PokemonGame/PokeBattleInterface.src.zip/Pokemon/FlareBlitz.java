/*   */ package Pokemon;
/*   */ 
/*   */ public class FlareBlitz extends Attack
/*   */ {
/*   */   public FlareBlitz()
/*   */   {
/* 7 */     super("Flare Blitz", "fire", 1.0D, 120, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.FlareBlitz
 * JD-Core Version:    0.6.0
 */