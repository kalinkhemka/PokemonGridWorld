/*   */ package Pokemon;
/*   */ 
/*   */ public class DragonPulse extends Attack
/*   */ {
/*   */   public DragonPulse()
/*   */   {
/* 7 */     super("Dragon Pulse", "dragon", 1.0D, 90, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.DragonPulse
 * JD-Core Version:    0.6.0
 */