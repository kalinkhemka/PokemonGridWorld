/*   */ package Pokemon;
/*   */ 
/*   */ public class FrenzyPlant extends Attack
/*   */ {
/*   */   public FrenzyPlant()
/*   */   {
/* 7 */     super("Frenzy Plant", "grass", 0.9D, 150, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.FrenzyPlant
 * JD-Core Version:    0.6.0
 */