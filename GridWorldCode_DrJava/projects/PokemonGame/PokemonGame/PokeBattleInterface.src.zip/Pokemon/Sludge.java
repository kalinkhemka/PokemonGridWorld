/*   */ package Pokemon;
/*   */ 
/*   */ public class Sludge extends Attack
/*   */ {
/*   */   public Sludge()
/*   */   {
/* 7 */     super("Sludge", "poison", 1.0D, 65, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Sludge
 * JD-Core Version:    0.6.0
 */