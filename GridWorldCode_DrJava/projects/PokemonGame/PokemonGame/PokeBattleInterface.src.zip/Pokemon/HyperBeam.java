/*   */ package Pokemon;
/*   */ 
/*   */ public class HyperBeam extends Attack
/*   */ {
/*   */   public HyperBeam()
/*   */   {
/* 7 */     super("Hyper Beam", "normal", 0.9D, 150, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.HyperBeam
 * JD-Core Version:    0.6.0
 */