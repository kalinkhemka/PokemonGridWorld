/*   */ package Pokemon;
/*   */ 
/*   */ public class VineWhip extends Attack
/*   */ {
/*   */   public VineWhip()
/*   */   {
/* 7 */     super("Vine Whip", "grass", 1.0D, 35, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.VineWhip
 * JD-Core Version:    0.6.0
 */