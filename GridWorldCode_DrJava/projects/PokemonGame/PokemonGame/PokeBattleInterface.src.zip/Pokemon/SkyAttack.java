/*   */ package Pokemon;
/*   */ 
/*   */ public class SkyAttack extends Attack
/*   */ {
/*   */   public SkyAttack()
/*   */   {
/* 7 */     super("Sky Attack", "flying", 0.9D, 140, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.SkyAttack
 * JD-Core Version:    0.6.0
 */