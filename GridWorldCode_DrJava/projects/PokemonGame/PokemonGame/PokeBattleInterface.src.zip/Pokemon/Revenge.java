/*   */ package Pokemon;
/*   */ 
/*   */ public class Revenge extends Attack
/*   */ {
/*   */   public Revenge()
/*   */   {
/* 7 */     super("Revenge", "fighting", 1.0D, 60, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Revenge
 * JD-Core Version:    0.6.0
 */