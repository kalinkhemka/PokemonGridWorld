/*   */ package Pokemon;
/*   */ 
/*   */ public class ThunderFang extends Attack
/*   */ {
/*   */   public ThunderFang()
/*   */   {
/* 7 */     super("Thunder Fang", "electric", 0.95D, 65, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.ThunderFang
 * JD-Core Version:    0.6.0
 */