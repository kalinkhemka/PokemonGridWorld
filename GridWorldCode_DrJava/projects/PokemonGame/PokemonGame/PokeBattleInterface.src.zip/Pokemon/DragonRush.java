/*   */ package Pokemon;
/*   */ 
/*   */ public class DragonRush extends Attack
/*   */ {
/*   */   public DragonRush()
/*   */   {
/* 7 */     super("Dragon Rush", "dragon", 0.75D, 100, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.DragonRush
 * JD-Core Version:    0.6.0
 */