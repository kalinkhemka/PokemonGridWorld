/*   */ package Pokemon;
/*   */ 
/*   */ public class MegaKick extends Attack
/*   */ {
/*   */   public MegaKick()
/*   */   {
/* 7 */     super("Mega Kick", "normal", 0.75D, 120, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.MegaKick
 * JD-Core Version:    0.6.0
 */