/*   */ package Pokemon;
/*   */ 
/*   */ public class RockTomb extends Attack
/*   */ {
/*   */   public RockTomb()
/*   */   {
/* 7 */     super("RockTomb", "rock", 0.8D, 50, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.RockTomb
 * JD-Core Version:    0.6.0
 */