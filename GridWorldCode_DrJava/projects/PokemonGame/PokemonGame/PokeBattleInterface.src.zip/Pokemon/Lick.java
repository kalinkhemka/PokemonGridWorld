/*   */ package Pokemon;
/*   */ 
/*   */ public class Lick extends Attack
/*   */ {
/*   */   public Lick()
/*   */   {
/* 7 */     super("Lick", "ghost", 1.0D, 20, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Lick
 * JD-Core Version:    0.6.0
 */