/*   */ package Pokemon;
/*   */ 
/*   */ public class Earthquake extends Attack
/*   */ {
/*   */   public Earthquake()
/*   */   {
/* 7 */     super("Earthquake", "ground", 1.0D, 100, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Earthquake
 * JD-Core Version:    0.6.0
 */