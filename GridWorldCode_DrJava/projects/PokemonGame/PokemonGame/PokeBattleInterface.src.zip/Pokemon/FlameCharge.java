/*   */ package Pokemon;
/*   */ 
/*   */ public class FlameCharge extends Attack
/*   */ {
/*   */   public FlameCharge()
/*   */   {
/* 7 */     super("FlameCharge", "fire", 1.0D, 50, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.FlameCharge
 * JD-Core Version:    0.6.0
 */