/*   */ package Pokemon;
/*   */ 
/*   */ public class ZenHeadbutt extends Attack
/*   */ {
/*   */   public ZenHeadbutt()
/*   */   {
/* 7 */     super("Zen Headbutt", "psychic", 0.9D, 80, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.ZenHeadbutt
 * JD-Core Version:    0.6.0
 */