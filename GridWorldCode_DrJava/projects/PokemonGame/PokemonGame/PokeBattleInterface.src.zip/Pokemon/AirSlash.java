/*   */ package Pokemon;
/*   */ 
/*   */ public class AirSlash extends Attack
/*   */ {
/*   */   public AirSlash()
/*   */   {
/* 7 */     super("Air Slash", "flying", 0.95D, 75, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.AirSlash
 * JD-Core Version:    0.6.0
 */