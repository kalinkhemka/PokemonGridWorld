/*   */ package Pokemon;
/*   */ 
/*   */ public class Astonish extends Attack
/*   */ {
/*   */   public Astonish()
/*   */   {
/* 7 */     super("Astonish", "ghost", 1.0D, 30, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Astonish
 * JD-Core Version:    0.6.0
 */