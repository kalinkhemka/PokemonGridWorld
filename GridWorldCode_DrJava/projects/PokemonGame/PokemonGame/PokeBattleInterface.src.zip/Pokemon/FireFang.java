/*   */ package Pokemon;
/*   */ 
/*   */ public class FireFang extends Attack
/*   */ {
/*   */   public FireFang()
/*   */   {
/* 7 */     super("Fire Fang", "fire", 0.95D, 65, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.FireFang
 * JD-Core Version:    0.6.0
 */