/*   */ package Pokemon;
/*   */ 
/*   */ public class TakeDown extends Attack
/*   */ {
/*   */   public TakeDown()
/*   */   {
/* 7 */     super("Take Down", "normal", 0.85D, 90, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.TakeDown
 * JD-Core Version:    0.6.0
 */