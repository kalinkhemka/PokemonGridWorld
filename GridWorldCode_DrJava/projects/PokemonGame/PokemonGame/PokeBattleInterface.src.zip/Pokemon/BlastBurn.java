/*   */ package Pokemon;
/*   */ 
/*   */ public class BlastBurn extends Attack
/*   */ {
/*   */   public BlastBurn()
/*   */   {
/* 7 */     super("Blast Burn", "fire", 0.9D, 150, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.BlastBurn
 * JD-Core Version:    0.6.0
 */