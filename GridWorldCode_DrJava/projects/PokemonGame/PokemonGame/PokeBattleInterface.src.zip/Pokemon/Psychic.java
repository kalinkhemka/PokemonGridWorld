/*   */ package Pokemon;
/*   */ 
/*   */ public class Psychic extends Attack
/*   */ {
/*   */   public Psychic()
/*   */   {
/* 7 */     super("Psychic", "psychic", 1.0D, 90, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Psychic
 * JD-Core Version:    0.6.0
 */