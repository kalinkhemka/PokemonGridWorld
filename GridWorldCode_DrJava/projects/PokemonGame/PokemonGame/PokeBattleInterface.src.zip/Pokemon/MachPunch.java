/*   */ package Pokemon;
/*   */ 
/*   */ public class MachPunch extends Attack
/*   */ {
/*   */   public MachPunch()
/*   */   {
/* 7 */     super("Mach Punch", "fighting", 1.0D, 40, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.MachPunch
 * JD-Core Version:    0.6.0
 */