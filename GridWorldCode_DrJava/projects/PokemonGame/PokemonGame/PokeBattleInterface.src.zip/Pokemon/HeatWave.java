/*   */ package Pokemon;
/*   */ 
/*   */ public class HeatWave extends Attack
/*   */ {
/*   */   public HeatWave()
/*   */   {
/* 7 */     super("Heat Wave", "fire", 0.9D, 100, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.HeatWave
 * JD-Core Version:    0.6.0
 */