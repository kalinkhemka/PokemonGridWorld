/*   */ package Pokemon;
/*   */ 
/*   */ public class FirePunch extends Attack
/*   */ {
/*   */   public FirePunch()
/*   */   {
/* 7 */     super("Fire Punch", "fire", 1.0D, 75, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.FirePunch
 * JD-Core Version:    0.6.0
 */