/*   */ package Pokemon;
/*   */ 
/*   */ public class Rollout extends Attack
/*   */ {
/*   */   public Rollout()
/*   */   {
/* 7 */     super("Rollout", "rock", 0.9D, 50, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Rollout
 * JD-Core Version:    0.6.0
 */