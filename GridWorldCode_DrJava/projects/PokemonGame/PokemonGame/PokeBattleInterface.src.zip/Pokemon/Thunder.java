/*   */ package Pokemon;
/*   */ 
/*   */ public class Thunder extends Attack
/*   */ {
/*   */   public Thunder()
/*   */   {
/* 7 */     super("Thunder", "electric", 0.7D, 120, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Thunder
 * JD-Core Version:    0.6.0
 */