/*   */ package Pokemon;
/*   */ 
/*   */ public class HydroCannon extends Attack
/*   */ {
/*   */   public HydroCannon()
/*   */   {
/* 7 */     super("Hydro Cannon", "water", 0.9D, 150, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.HydroCannon
 * JD-Core Version:    0.6.0
 */