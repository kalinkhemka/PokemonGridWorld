/*   */ package Pokemon;
/*   */ 
/*   */ public class MegaPunch extends Attack
/*   */ {
/*   */   public MegaPunch()
/*   */   {
/* 7 */     super("Mega Punch", "normal", 0.85D, 80, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.MegaPunch
 * JD-Core Version:    0.6.0
 */