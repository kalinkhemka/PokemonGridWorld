/*   */ package Pokemon;
/*   */ 
/*   */ public class QuickAttack extends Attack
/*   */ {
/*   */   public QuickAttack()
/*   */   {
/* 7 */     super("QuickAttack", "normal", 40.0D, 100, false);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.QuickAttack
 * JD-Core Version:    0.6.0
 */