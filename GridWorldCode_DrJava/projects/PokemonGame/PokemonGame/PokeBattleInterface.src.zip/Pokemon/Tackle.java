/*    */ package Pokemon;
/*    */ 
/*    */ public class Tackle extends Attack
/*    */ {
/*    */   public Tackle()
/*    */   {
/* 14 */     super("Tackle", "Normal", 0.5D, 100, false);
/*    */   }
/*    */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Tackle
 * JD-Core Version:    0.6.0
 */