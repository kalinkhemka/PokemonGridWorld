/*   */ package Pokemon;
/*   */ 
/*   */ public class Flamethrower extends Attack
/*   */ {
/*   */   public Flamethrower()
/*   */   {
/* 7 */     super("Flame Thrower", "fire", 1.0D, 95, true);
/*   */   }
/*   */ }

/* Location:           C:\Users\Owner\Documents\BellarmineDocs\2010-2011\Java\GridWorldCode_DrJava\projects\PokemonGame\PokeBattleInterface.jar
 * Qualified Name:     Pokemon.Flamethrower
 * JD-Core Version:    0.6.0
 */